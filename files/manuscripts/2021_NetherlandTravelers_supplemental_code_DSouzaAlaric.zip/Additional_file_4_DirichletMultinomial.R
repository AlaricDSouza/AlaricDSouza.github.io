#!/usr/bin/env Rscript

#File Name    : DirichletMultinomial.R
#Author       : Alaric D'Souza, alaric.dsouza@wustl.edu
#Created On   : Wed Oct  2 15:33:58 CDT 2019
#Last Modified: Wed Oct  2 15:34:03 CDT 2019
#Description  : Takes in community data matrix and outputs Dirichlet Multinomial model object
#Usage: DirichletMultinomial.R -i <inputfile (community data matrix)> -o <output directory>

#install and load required package
library("optparse")
library("DirichletMultinomial")

#take in arguments
option_list = list(
  make_option(c("-i", "--inputfile"), action="store", default=NA, type='character',
              help="community matrix file"),
  make_option(c("-o", "--outputdirectory"), action="store", default=NA, type='character',
              help="output directory"),
  make_option(c("-s", "--currseed"), action="store", default=sample(1:10000, 1), type='integer',
              help="seed value for this run [default %default]"),
  make_option(c("-n", "--numclust"), action="store", default=7, type='integer',
              help="maximum number of clusters [default %default]"),
  make_option(c("-t", "--threads"), action="store", default=1, type='integer',
              help="threads available [default %default]")  
)
#parse arguments to list
opt = parse_args(OptionParser(option_list=option_list))

# main point of program is here, do this whether or not "verbose" is set
if(!is.na(opt$inputfile) & !is.na(opt$outputdirectory)) {
#create output directory
dir.create(opt$outputdirectory)

renormMatrix <- function(inmatrix){
    return(inmatrix/(min(inmatrix[inmatrix>0])))
    }

dmnOutput<- mclapply(1:opt$numclust,
    #call dmn function
    dmn,
    #read in community data matrix
    count=renormMatrix(as.matrix(read.table(file=opt$inputfile,sep="\t",row.names=1,header=T))),
    #report state to standard out
    verbose=TRUE,
    #seed for dmn model
    seed=opt$currseed,
    #number of threads available for mclapply
    mc.cores=opt$threads)


#save the output file
saveRDS(dmnOutput,
  file=file.path(opt$outputdirectory, paste0("DMM_",opt$numclust,"k_",opt$currseed,".rds")))

} else {
    cat("you didn't specify both input file and output directory\n", file=stderr()) # print error messages to stderr
}
